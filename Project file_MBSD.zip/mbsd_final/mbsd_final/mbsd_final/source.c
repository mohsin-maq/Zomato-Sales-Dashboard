 /******************************************************************************
 *
 * File Name: source.c
 *
 * Description: Application
 *
 *
 *******************************************************************************/
#include "lcd.h"
#include "dc_motor.h"
#include <avr/io.h>
#include <util/delay.h>

char GetKeyPressed(void);


int main(){
	DDRA = 0x0F;  // Set lower 4 bits of Port C as output for keypad rows (connected to cathodes)
	PORTA = 0xF0;  // Set upper 4 bits of Port C as input with pull-up resistors for keypad columns (connected to anodes)

	/* initialize dc-motor driver */
	DcMotor_Init();

	/* initialize LCD driver */
	LCD_init();

	/*print state of fan in the first line*/
	LCD_displayString("   FAN is");
	/*print temperature in the second line*/
	LCD_moveCursor(1,0);
	LCD_displayString("   Temp =     C");

	/*print speed of motor in third line*/
	LCD_moveCursor(2,0);
	LCD_displayString("   speed =    %");

	/*temp Variable to store the temperature value measured by LM35*/
	uint8 temp;

	/*string variable to store fan working ON/OFF*/
	char* fan_work="OFF";

	/*variables to store fan info */
	uint8 motor_speed=0;
	uint8 motor_state=motor_stop;

	while(1)
	{
	char digits[2] = {'_', '_'};  // Array to store the entered digits
	uint8_t digitIndex = 0;  // Index to track the current digit position

	while (digitIndex < 2)
	{
		char key = GetKeyPressed();
		if (key != '\0')
		{
			digits[digitIndex] = key;  // Store the entered digit

			uint8_t digitValue = key - '0';  // Convert the entered character to a numeric value

			//PORTB = digitPatterns[digitValue];  // Display the entered digit on the 7-segment display
			_delay_ms(500);  // Delay for 500 milliseconds
			//PORTB = 0x00;  // Turn off the 7-segment display

			digitIndex++;  // Increment the digit index
		}
	}

	// Combine the digits to form a two-digit number
	uint8_t temp = (digits[0] - '0') * 10 + (digits[1] - '0');

		
		/*display periodically periodically*/
		LCD_moveCursor(1, 10);
		LCD_intgerToString(temp);
		if(temp<0)
			LCD_displayCharacter(' ');

		if(temp < 5)
		{
			/*if temperature is less than 30 :
			 * change  state of fan to OFF
			 * speed of  fan = 0
			 *  */
			motor_speed=0;
			motor_state=motor_stop;
			fan_work="OFF";

		}else{
			/*if temperature is less than 30 :
			 * change  state of fan to ON and control direction
			 * speed of  fan depend on temperature
			 *  */
			fan_work = "ON ";
			motor_state=motor_CW;

			if (temp < 25) {
				motor_speed=25;
			}
			else if(temp< 50) {
				motor_speed=50;
			}
			else if(temp<100) {
				motor_speed=100;
			}
		}

		/*control speed and motor speed*/
		DcMotor_Rotate(motor_state,motor_speed);

		/*print fan working: OFF/ON */
		LCD_moveCursor(0, 10);
		LCD_displayString(fan_work);

		/*print fan speed*/
		LCD_moveCursor(2, 11);
		LCD_intgerToString(motor_speed);
		if(motor_speed<100)
					LCD_displayCharacter(' ');
	}

	return 0;
}
char GetKeyPressed(void)
{
	char keypad[4][4] = { // Define the keypad matrix
		{'1', '2', '3', 'A'},
		{'4', '5', '6', 'B'},
		{'7', '8', '9', 'C'},
		{'*', '0', '#', 'D'}
	};

	for (uint8_t col = 0; col < 4; col++)
	{
		PORTA = ~(1 << col);  // Enable the current column

		for (uint8_t row = 0; row < 4; row++)
		{
			if (!(PINA & (1 << (row + 4))))  // Check if the current row is pressed
			{
				_delay_ms(10);  // Debounce delay

				if (!(PINA & (1 << (row + 4))))  // Check again to confirm the keypress
				{
					while (!(PINA & (1 << (row + 4))));  // Wait for the key to be released

					return keypad[row][col];  // Return the corresponding character
				}
			}
		}
	}

	return '\0';  // Return null character if no key is pressed
}
